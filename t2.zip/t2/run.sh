javac Main.java; java Main
