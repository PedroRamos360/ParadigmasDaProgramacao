# Trabalho 2 - Estrutura de dados

## Exercícios de streams e funções lambda

### Exercício 1

Análise de salário e número de filhos de uma população

### Exercício 2

Simulador de urna eleitoral

### Exercício 3

Média ponderada de provas de alunos

### Exercício 4

Contador de frequência de intervalos

### Exercício 5

Cálculo de aumento de preços de uma empresa em 20%

## Rodar projeto

```bash
bash run.sh
```

ou

```bash
chmod +x run.sh
./run.sh
```
